//
//  ViewController.swift
//  BlockTable
//
//  Created by Mac on 4/13/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class ViewController: UIViewController ,UITableViewDelegate,UITableViewDataSource {
    
    

    var aryData = [String]()
    @IBOutlet var tblView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
     
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }

    @IBAction func ActionADD(_ sender: UIBarButtonItem)
    
    {
        let VC = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "InsertViewController")as? InsertViewController
        
        VC!.BlockbtnClick = { str in
            
            self.aryData.append(str)
            self.tblView.reloadData()
        }
        
        navigationController?.pushViewController(VC!, animated: true)
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return aryData.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        
        cell?.textLabel?.text = aryData[indexPath.row]
        cell?.detailTextLabel?.text = aryData[indexPath.row]
        
        return cell!
    }
}

