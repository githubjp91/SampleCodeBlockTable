//
//  InsertViewController.swift
//  BlockTable
//
//  Created by Mac on 4/13/18.
//  Copyright © 2018 agile. All rights reserved.
//

import UIKit

class InsertViewController: UIViewController {
    
    var BlockbtnClick:((String)-> Void)?
    
    
    @IBOutlet var txtID: UITextField!
    @IBOutlet var txtPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func ActionGO(_ sender: UIButton)
    {
        if BlockbtnClick != nil
        {
            BlockbtnClick!(txtID.text!)
            BlockbtnClick!(txtPassword.text!)
                self.navigationController?.popViewController(animated: true)
        }
    }
    
}
